/**
 * Created by Jacky.Gao on 2017-10-13.
 */
import FormBuilder from './FormBuilder.js';

$(document).ready(function(){
    new FormBuilder($("#container"));
});