/**
 * Created by Jacky.Gao on 2017-03-16.
 */
import Slash from './Slash.js';

export default class MiddleSlash extends Slash{
    constructor(width,height,fontSize){
        super(width,height,fontSize);
    }
    init(){

    }
}
